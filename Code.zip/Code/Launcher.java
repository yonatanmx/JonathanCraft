

public class Launcher {
    public static void main(String[] args) {
           Game game = new Game("sup", 700, 700);
           game.start();
    }

}
//9